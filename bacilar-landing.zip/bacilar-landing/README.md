# Bacılar Landing Page

Next.js App Router ile hazırlanmış, Vercel'e hazır landing page.

## Çalıştırma

```bash
npm install
npm run dev
```

Tarayıcıda `http://localhost:3000` aç.

## Vercel'e yükleme

1. Bu klasörü GitHub reposuna yükle.
2. Vercel > New Project > repo'yu seç.
3. Framework otomatik olarak Next.js algılanır.
4. Deploy'a bas.

## Güncellenecek yerler

- `components/Hero.tsx` ve `components/FinalCTA.tsx` içindeki `Uygulamayı indir` linklerinde `href="#"` var. App Store linki hazır olunca gerçek bağlantıyla değiştir.
- Footer'daki Instagram, TikTok, KVKK, Gizlilik ve Koşullar şimdilik `Yakında` olarak gösteriliyor.
- Uygulama içi görseller şu an HTML/CSS ile oluşturulmuş konsept ekranlardır; elindeki gerçek Bacılar ekran görüntülerini `public/` içine koyup `next/image` ile değiştirebilirsin.
- `public/bee-icon.png` senin gönderdiğin arı ikonudur.

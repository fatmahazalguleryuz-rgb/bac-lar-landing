import Image from 'next/image';
export default function FinalCTA(){return <section className="section"><div className="container final-cta"><div><h2>Sen de aramıza katıl.</h2><p>Kadınların kendi aralarında konuştuğu yer.</p></div><a href="#" className="button"> Uygulamayı indir</a><Image src="/bee-icon.png" width={74} height={74} alt="Bacılar arı ikonu"/></div></section>}
